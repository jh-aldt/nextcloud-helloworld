<?php

declare(strict_types=1);
// SPDX-FileCopyrightText: JH ALDT <j.henriquez@aledit.com>
// SPDX-License-Identifier: AGPL-3.0-or-later

namespace OCA\HelloWorld\Service;

class NoteNotFound extends \Exception {
}
